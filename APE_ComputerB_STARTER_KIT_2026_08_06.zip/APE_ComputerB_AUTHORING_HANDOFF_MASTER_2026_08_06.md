# AP&E Studio — MASTER Glossary Authoring Handoff — **COMPUTER B**
**Status: CANDIDATE — PENDING PROF. BOOTH APPROVAL. Nothing is written to the live DB by this package.**
**Assignment:** Computer B authors + committee-checks **all 3,362 net-new terms** from the 2026-08-06 combined dedup (A–Z dictionary, Numbers, drum-recording, and game-audio career/workplace waves).
**Worklist / manifest:** `APE_ComputerB_MASTER_WAVE_MANIFEST.csv` — every term with its `packet_id` (`b0001`–`b3362`), `source_bucket`, `wave`, `batch_in_wave`, `agent_slot`, `parallel_round`.
**Source of terms:** `MASTER_KEEP_to_author.csv` (2,862 A–Z + 373 Drums + 23 Numbers + 104 Career = 3,362). All already deduped against live `glossary` (~22,744) and alias-cleaned — **only canonical terms that will actually be authored are here**; folded plural/alias variants are recorded separately in `ALIAS_FOLDS_not_authored.csv` and are NOT authored.

> **Supersedes** the standalone `APE_DRUMS_AUTHORING_PACKAGE_ComputerC_2026_08_06_CLEANED.md` — its 373 drum packets are rolled into this master run (source_bucket = `Drums-C`, same proposed homes). One machine, one pipeline.

> **⚠️ These 3,362 terms do NOT exist in `glossary` yet.** Every content field is empty → author **all 8 fields** per term. **Structural fields (row creation, topic/achievement_id, difficulty, IDs) are Booth's to set — agents must not invent them (Rule 4).** §C carries PROPOSED homes by bucket.

---

# §A — AUTHORING STANDARD (THE COMMITTEE) — byte-identical to `APE_Glossary_Authoring_AGENT_PROMPT_2026_06_26.md`

## YOUR ROLE
You are an **expert audio researcher and working systems technician** with deep, current knowledge of professional audio: studio recording, live sound reinforcement, AV integration, RF/wireless, loudspeaker and amplifier systems, signal flow, and — critically — the **electrical, grounding, rigging, and personal-safety** practices that govern this work in the field. You are authoring reference content for an app that **certifies student technicians for real studio and live-sound access.** Inaccurate content can cause equipment damage, injury, or death. You write with that responsibility in mind.

## THE MISSION (per batch)
Research and author the **empty fields only** of each glossary term, to a standard a professional educator and a safety officer would both sign off on. **You fill blanks. You never touch content that already exists.** *(Master run note: these are new terms — every content field is empty, so you author all 8. You still never set structural fields, per Rule 4.)*

## NON-NEGOTIABLE RULES
1. **FILL EMPTY FIELDS ONLY. NEVER MODIFY, IMPROVE, REWRITE, OR OVERWRITE ANY FIELD THAT ALREADY HAS CONTENT.**
2. **NO HALLUCINATION. NO GUESSING. EVER.** Every fact, value, spec and claim must be **verifiable against authoritative sources.** If you cannot confirm to a professional standard, **do not invent it** — leave the field blank and **flag the term for human review** with a note on what couldn't be confirmed. A blank, flagged field is correct; a confident wrong answer is a failure.
3. **SAFETY CONTENT IS HELD TO THE HIGHEST BAR.** For anything touching voltage, current, power, grounding/bonding, ground-lifting, phantom power, rigging, lifting, ladders, fall protection, or hearing-damaging SPL: state established, standards-based practice only (NEC/NFPA 70, NFPA 70E, OSHA, ANSI/ESTA, IEC, IEEE, manufacturer safety docs). Never present an unsafe shortcut, folklore, or "common workaround" as correct — dangerous practice belongs in `common_mistakes`, clearly marked as unsafe.
4. **DO NOT ALTER STRUCTURAL FIELDS.** Never set/change a term's name, its course/topic assignment, its difficulty level, or any ID. You author **content only.**
5. **RESPECT DISAMBIGUATED TERMS.** A term with a parenthetical sense (e.g. `Volume (game engine)` vs the existing audio `Volume`) defines **only the named sense** — do not blend meanings.
6. **CROSS-CONFIRM.** Every definition and fact corroborated by **≥2 independent authoritative sources** (≥3 for safety-critical/contested). If sources disagree, prefer standards bodies and primary manufacturer documentation; note the discrepancy for review.

## AUTHORITATIVE SOURCES (use several; cross-confirm)
Prefer primary and professional sources; do **not** rely on forums, SEO content, Q&A sites, or AI-generated text for facts. AES standards & e-library; *Yamaha Sound Reinforcement Handbook*; *Sound Systems: Design and Optimization* (McCarthy); *Handbook for Sound Engineers* (Ballou); Sound on Sound; Rane notes; manufacturer primary docs. Electrical/safety (required for any safety claim): NEC/NFPA 70, NFPA 70E, OSHA 29 CFR 1910/1926, ANSI/ESTA/PLASA E1, IEC/IEEE.

## FIELDS TO AUTHOR (only if empty)
| Field | What to write | Length |
|---|---|---|
| `definition` | Precise, technically correct core definition for this term/sense. Self-contained. | 1–3 sentences |
| `plain_english` | Same idea for a beginner — minimal jargon; an accurate everyday analogy welcome. | 1–2 sentences |
| `purpose_function` | What it does and **why it exists** in a system. | 1–2 sentences |
| `practical_application` | How a technician actually **uses or encounters** it on the job. | 1–2 sentences |
| `category` | Short grouping label — **match the category used by sibling terms in this topic** where one exists. | 1–4 words |
| `related_terms` | Cross-references to **other glossary terms** a student should know alongside this one. | list, 3–6 |
| `common_mistakes` | Typical student errors/misconceptions — **mark any safety-relevant ones.** | list, 2–4 |
| `scenario_contexts` | Concrete real-world situations where the term applies. | list, 2–4 |

## OUTPUT FORMAT (per term)
```
TERM: <exact term>
— definition:            <new text>
— plain_english:         <new text>
— purpose_function:      <new text>
— practical_application: <new text>
— category:              <new value>
— related_terms:         <item; item; item>
— common_mistakes:       <item; item>   (mark unsafe ones)
— scenario_contexts:     <item; item>
SOURCES: <source 1; source 2; (source 3 for safety)>
CONFIDENCE: High | Medium | FLAG-FOR-REVIEW (+ reason if not High)
```
- Sources go on the SOURCES line only — **never inside field content** (SOURCES/CONFIDENCE must not reach the DB). Semicolons separate list items.

## WHAT NOT TO DO
❌ edit/rewrite existing content · ❌ invent specs/values/standards/models · ❌ present unsafe practice as correct · ❌ add/remove terms or change names/topics/difficulty/IDs · ❌ put citations in field content · ❌ fill a field you can't confirm.

---

# §B — RUN ARCHITECTURE (Booth-requested)
**Shape:** 7 waves × batches of 50 × 6 agents authoring simultaneously.

| | |
|---|---|
| Total terms | **3,362** (`b0001`–`b3362`) |
| Wave size | **500** (Waves 1–6 = 500 each; Wave 7 = **362**) |
| Batch size | **50 terms** |
| Batches / wave | 10 (Wave 7 = 8) — **68 batches total** (67 × 50 + 1 × 12) |
| Concurrency | **6 agents** author in parallel → **2 rounds per wave** (Round 1 = batches 1–6, Round 2 = batches 7–10) |
| Agent slots | `A1`–`A6`; batch→agent is round-robin (see manifest `agent_slot`, `parallel_round`) |

**Batches are domain-coherent.** The manifest orders terms A–Z audio → Numbers → Drums → Career, so each 50-term batch stays in one subject. That keeps an agent's sources, category labels, and cross-refs local — higher accuracy *and* less wasted research. Waves 1–5 + start of 6 = A–Z; Wave 6 tail = Numbers + start of Drums; Wave 7 = rest of Drums + all Career.

**Wave gating (critical):** do **not** begin authoring Wave *N+1* until Wave *N* has passed committee, been merged by Booth, and re-deduped clean against the now-larger live glossary. Each merged wave enlarges the corpus, so a later wave's term may collide with, or should cross-reference, a just-added earlier-wave term. Gating prevents duplicate authoring and keeps `related_terms` valid.

---

# §C — STRUCTURAL PREREQUISITE / TOPIC ROUTING (BOOTH-OWNED — Rule 4)
Homes below are **PROPOSED** by source bucket. Booth confirms/edits, then creates stub rows (§F) before authoring. Difficulty is proposed per bucket; set per-term where siblings vary.

| Source bucket (count) | Proposed home(s) |
|---|---|
| **A–Z audio dictionary (2,862)** | Route by concept to existing audio topics; most are general audio/electronics/acoustics vocabulary. Recommend a first-pass auto-home by keyword against the topic taxonomy, Booth-reviewed. Standards/units kept in the dedup (ANSI, AES, ASA, SI, ISRC…) → standards/reference topic. |
| **Numbers / reference levels (23)** | Levels & metering / decibel-reference topic (0 dBu, 0 dBV, 94 dB-SPL, −174 dBm/Hz), plus surround-format and record-speed terms to their nearest playback/format topic. |
| **Drums-C (373)** | Exactly the Comp-C proposed homes: gs 3880 Drum-Kit Recording; gs 3890 Instrument Mixing–Drums & Percussion; gs 3840 Recording Fundamentals & Signal Chain; gs 3860 Band Tracking Workflow; gs 4320 Attack/Decay/Resonance; gs 3130 Stereo & Ensemble Miking. (Per-packet in the Comp-C batch CSV.) |
| **Career / game-audio (104)** | **Job Roles (29) + Professional Skills (17) → Workplace-Skills / Business-Employment topic(s)** (Booth to name the achievement_id, likely new). Implementation/pipeline, interactive-audio, tools, programming, recording/dialogue → game-audio / production topics. The 4 disambiguated headwords — Volume (game engine), Trigger (game engine), Layer (interactive audio), Transition (interactive audio) — define only their named sense (Rule 5). |

*Note: expanded-taxonomy topics resolve with `course_id = NULL`; the sibling-category/related-term validation query keys on `achievements.global_sequence`, not `courses.code`.*

---

# §D — ACCURACY-WITH-EFFICIENCY INSTRUCTIONS (suggested for Computer B)

**Accuracy guardrails**
1. **Flag-don't-guess is absolute.** Any unconfirmable field → blank + `FLAG-FOR-REVIEW` with the reason; the term goes to the running register on Booth's machine (`~/dev/ape-studio/FLAGGED_TERMS/`), safety items first. Never pad a batch to hit a count.
2. **Tiered sourcing to save time without losing rigor:** non-safety terms = ≥2 independent authoritative sources; **only** safety/exposure-bearing terms (voltage, current, grounding, phantom power, rigging, hearing-damaging SPL) escalate to ≥3 incl. a standards body. Most Career/pipeline/interactive terms are non-safety → author faster.
3. **Shared, locked reference spine per domain.** Before a wave, publish a one-page canonical source list + spelling/style sheet per bucket (e.g., "microphone" not "mic" in `definition`; "loudspeaker" house style; unit formatting). All 6 agents cite from the same spine so parallel output doesn't diverge.
4. **Shared category ledger.** Maintain one live category-label ledger across the 6 agents per wave. Before inventing a `category`, an agent checks the ledger + sibling terms in the proposed topic; new labels are added once and reused — prevents 6 agents coining 6 names for one concept.
5. **Cross-reference discipline.** `related_terms` must point at **real** glossary terms — already-live, or authored in the **same or an earlier wave** (never a later, not-yet-authored wave). Validate against the live table + the current wave's term list before delivery.
6. **Respect disambiguation & trademark tags.** Parenthetical senses define only that sense. Trademark/proprietary terms: author neutral, factual content; do not endorse vendor marketing claims; symbols/attribution handled at import, never inside field text.
7. **Committee check every batch, not just every wave.** Run the standard multi-lens committee (audio-accuracy / cognition-clarity / language / legal-safety) on each 50-batch as it lands; `NEEDS_REVISION` items loop back to the authoring agent before the wave closes.

**Efficiency levers**
8. **Domain-coherent batches (already built into the manifest)** — agents stay in one subject per 50, reusing sources and context.
9. **Self-contained, resumable batches.** Each batch = its 50 packet_ids + the standard + the domain source spine. A failed/interrupted agent re-runs only its 50; no shared mutable state beyond the append-only category ledger and flag register.
10. **Structured, machine-parseable output** exactly per §A OUTPUT FORMAT, one block per term, so committee diffing and Booth's import are mechanical (no reformatting pass).
11. **Manifest reconciliation per batch:** IDs-in == IDs-out, 8 fields present or explicitly flagged, 0 stray citations/URLs in field text, 0 SOURCES/CONFIDENCE leakage. A batch that fails reconciliation doesn't advance to committee.
12. **Wave-close checklist before Booth import:** (a) all batches reconciled, (b) committee clean or flagged, (c) category ledger merged, (d) `related_terms` validated, (e) re-run the dedup against live to confirm 0 new collisions. Then Booth merges, and only then does the next wave start (§B gating).
13. **Parallelize research, serialize truth.** Agents may research concurrently, but the category ledger, flag register, and dedup re-check are single-writer per wave to avoid drift.

---

# §E — DATA ACCESS (Supabase `yjgolswjggmlpeowvtxr`) — read-only for agents
Rows don't exist yet; the batch input is the manifest, not a DB pull. Use the DB only to (a) match sibling `category` labels in the proposed home topic and (b) validate `related_terms` are real glossary terms.
```sql
-- (a) sibling categories already used in a proposed home topic:
SELECT DISTINCT g.category FROM glossary g JOIN glossary_topics gt ON gt.glossary_id=g.id
JOIN achievements a ON a.id=gt.achievement_id
WHERE a.global_sequence = :gs AND g.category IS NOT NULL AND g.category <> '';
-- (b) validate related_terms point at real glossary terms:
SELECT term FROM glossary WHERE term IN ('Candidate 1','Candidate 2', ...);
```

# §F — DELIVERY → COMMITTEE → IMPORT FLOW (per wave)
1. **Author** each term per §A into a review log — NOT the database.
2. **Committee/human review** per batch: ≥2 sources (≥3 safety), accuracy, disambiguation, formatting. `FLAG-FOR-REVIEW` stays blank until resolved; flagged terms → `~/dev/ape-studio/FLAGGED_TERMS/`.
3. **Import (Booth only, on go-ahead).** NEW rows → guarded/idempotent `INSERT … WHERE NOT EXISTS (SELECT 1 FROM glossary WHERE term=$$…$$)`, dated `_backup_glossary_<yyyymmdd>` first; link `glossary_topics` (glossary_id, achievement_id, difficulty, is_primary) — exactly one `is_primary` per term; `term` is globally UNIQUE. SOURCES/CONFIDENCE never stored. Same pattern proven on the Computer-B cymatics merge.
4. **Verify** after each wave: term count rose by the wave's expected number; each new row has content + exactly one primary topic; no existing row changed; re-run dedup → 0 new collisions. **Then** release the next wave.

# §G — OPEN DECISIONS (Prof. Booth — Analysis Mode)
1. **Packet-id range** `b0001`–`b3362` (continues the b-prefix). Confirm, or namespace by bucket.
2. **A–Z homing method** — auto-home-by-keyword then review, vs. Booth places each; and which topic holds standards/units.
3. **Career topics** — name the Workplace-Skills / Business-Employment achievement_id(s) for Job Roles + Professional Skills (likely new topics).
4. **Numbers homing** — levels/metering topic vs. per-term.
5. **Difficulty** — per-bucket defaults vs. per-term.
6. **Stub-first vs author-then-INSERT** — create empty stub rows so agents run the fill-empty pipeline unchanged, or author offline then INSERT complete rows.
7. **Wave order** — proposed audio-first (A–Z → Numbers → Drums → Career). Reorder if a topic is needed live sooner.

---
*CANDIDATE — Pending Approval. Committee standard byte-identical to `APE_Glossary_Authoring_AGENT_PROMPT_2026_06_26.md`. Dedup/clean basis: live `glossary` ~22,744, combined set 2026-08-06. Proposed homes evidence-grounded but Booth-owned (Rule 4). No live-DB change performed.*
