# ⁩ PASTE THIS INTO MACHINE B TO AUTHOR THE ADDITIONAL TERMS ⁩

**Standalone batch: 843 terms · 6744 fields · 72 packets.** Missing shorthand/alias + standards + manufacturer-lexicon terms an audit found absent from the glossary. Prof. Booth approved this list across phases (shorthand; standards; Pro Tools/Yamaha; Ableton; Sony; SSL; Allen & Heath; Avid; Apple Logic; Steinberg; Universal Audio; Waves; Native Instruments). NEW terms — AUTHOR all 8 fields from scratch; Machine A inserts on return (backup + checksum). Never change an `id` or `term`. You never write to any DB.

Pipeline every term: 1) Author (`briefs/AUTHORING_BRIEF.md`, honor `authoring_note`) → 2) Committee (all 3 experts) → 3) Corrections (`EDITOR_BRIEF.md`, web-verify) → 4) Readability gate (`python3 tools/check_readability.py corrected_OUTPUT`, then `REWRITE_BRIEF.md`).

Four overriding rules: never author without the committee · no placeholders ever · strict sourcing (standards bodies / manufacturer TECHNICAL docs / recognised texts; ≥2 per fact, ≥3 safety) · `plain_english` ≤ grade 9 (run the gate).

**BRAND / TRADEMARK RULE (this batch is very heavy with trademarks):** define trademarks neutrally and factually from the maker's own technical documentation — never marketing superlatives. State what it is, what it does, where the user meets it, who owns it, era/context. The *name* is proprietary; the *method* is often generic — say so and credit the concept. Note shared/older terms honestly (VST/ASIO originated at Steinberg but are cross-industry; UA tape/console Extensions name API/Neve/Studer/Ampex gear they model, not UA inventions). For file formats / model numbers, emphasize what it is and the troubleshooting/interchange implication.

**Deadline: 15 August, zero placeholders.** Checkpoint each packet to disk. Return `authored_OUTPUT/`, `committee_OUTPUT/`, `corrected_OUTPUT/`, `COMPLETION_NOTES.md`.
