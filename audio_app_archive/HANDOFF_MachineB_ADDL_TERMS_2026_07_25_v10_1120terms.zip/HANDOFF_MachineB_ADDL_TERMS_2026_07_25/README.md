# AP&E Glossary — Machine B · Additional Terms (1120 terms)

**1120 terms · 97 packets · 8960 fields.** Includes 196 Phase-50 audio EQUATIONS (`eq_*`, each with formula_symbolic+formula_words + click-swap note) and math/physics phases. Never change id/term. Sources in `sources` array. Follow BRAND/TRADEMARK + EQUATION rules in HANDOFF_PROMPT.md.