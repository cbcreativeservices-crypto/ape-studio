

**EQUATION ENTRIES (`eq_*`, has_formula):** verify `formula_symbolic`, rewrite `formula_words` into clean spelled-out form + legend, author 8 fields. APP FEATURE: symbolic large, worded small lower-right, tap to swap. DB now HAS `formula_symbolic`/`formula_words` columns on glossary — Machine A populates them on insert.
