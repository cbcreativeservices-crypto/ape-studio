# ⁩ PASTE THIS INTO MACHINE B TO AUTHOR THE ADDITIONAL TERMS ⁩

**Standalone batch: 1103 terms · 8824 fields · 93 packets.** Missing shorthand/alias + standards + manufacturer-lexicon + mathematics + AUDIO EQUATIONS. Booth-approved across phases. NEW terms — AUTHOR all 8 fields from scratch; Machine A inserts on return (backup + checksum). Never change an `id` or `term`. You never write to any DB.

Pipeline every term: Author (`AUTHORING_BRIEF.md`, honor `authoring_note`) -> Committee (3 experts) -> Corrections (`EDITOR_BRIEF.md`, web-verify) -> Readability gate (`python3 tools/check_readability.py corrected_OUTPUT`). Four rules: never author without committee; no placeholders; strict sourcing (standards bodies / manufacturer technical docs / recognised texts; >=2 per fact, >=3 safety); plain_english <= grade 9.

**BRAND / TRADEMARK RULE:** define trademarks neutrally from the maker's technical docs — never marketing superlatives; name is proprietary, method often generic; note shared/older terms honestly.

**EQUATION ENTRIES (Phase 50, packets tagged `eq_*`, `has_formula:true`):** each carries `formula_symbolic` and an auto-generated `formula_words`. YOU MUST: (1) verify the symbolic formula, (2) rewrite `formula_words` into a clean fully-spelled-out form (e.g. Energy = Mass x SpeedOfLight^2) and supply a symbol legend, (3) author the 8 standard fields (definition = what it computes + when/why an engineer uses it; practical_application = worked example with realistic numbers and units; common_mistakes = unit/log errors; scenario_contexts). Cite OpenStax/NIST/OSHA/standards, not blogs.
**APP FEATURE (record; do not build):** the client shows the symbolic formula large with the worded form small in the lower-right corner; tapping the card swaps them (worded large, symbols to the corner), tap again to swap back. Symbolic renders via MathJax/LaTeX. DB needs to store both forms per equation (two columns or a formulas table).

**Deadline: 15 August, zero placeholders.** Checkpoint each packet. Return `authored_OUTPUT/`, `committee_OUTPUT/`, `corrected_OUTPUT/`, `COMPLETION_NOTES.md`.
