# ⇩ PASTE THIS INTO MACHINE B TO AUTHOR THE ADDITIONAL (MISSING-SHORTHAND) TERMS ⇩

---

**Standalone batch: 177 terms · 1,416 fields · 20 packets.** Common-shorthand / alias / standards & compliance terms an audit found missing from the glossary (e.g. *Outcue*, *Deadwax*, *Clockwheel*, *Headstage*, *Spinorama*, *HRTF*, *AES*, *FCC*, *CE Marking*, *dialnorm*). Prof. Booth approved this exact list. Do **not** add, drop, or re-scope terms.

These terms do **not exist in the database yet.** You AUTHOR them from scratch — every field in each term's `empty_fields` (all 8). Machine A INSERTS your returned output into production (with backup + checksum). **You never write to any database.** Never change a term's `id` (Machine A inserts on that id) or its `term`.

Read `README.md`, then run our standard four-step pipeline on every term:

1. **Author** — `briefs/AUTHORING_BRIEF.md`. Author all 8 fields. Keep `id`, `term`, `topic`, `topic_id`, `difficulty`, and any `cross_list_topics` exactly as given. Honor each term's `authoring_note` if present.
2. **Committee (mandatory)** — all three experts over every term: `BRIEF_COMMON.md` + `BRIEF_AUDIO.md` + `BRIEF_COGNITION.md` + `BRIEF_LANGUAGE.md`.
3. **Corrections** — `briefs/EDITOR_BRIEF.md`, web-verifying each technical fix.
4. **Readability gate (do not skip)** — `python3 tools/check_readability.py corrected_OUTPUT`, then `briefs/REWRITE_BRIEF.md` until it passes.

**The four rules that override everything:**
- **Never author without the committee.** Every term, all three experts. Standing rule from Prof. Booth.
- **No placeholders, ever.** `(definition pending)` / `(pending)` = not written. Author it. Cannot confirm a fact from a qualifying source? Leave that field blank and flag it.
- **Source quality.** Wikipedia, Reddit, forums, blogs, SEO/AI text and vendor *marketing* do NOT count — pointers only, never cited. Every source must be a standards body (FCC Part 73/11, AES, IEC, ISO, ITU-R BS.1770/EBU R128, IEEE, SMPTE), manufacturer *technical* documentation, or a recognised professional text. ≥2 per fact, ≥3 for safety/regulatory.
- **`plain_english` ≤ grade 9** — a 14-year-old must understand it, sentences ≤ 20 words. Run the gate; do not trust the committee's eye.

**Domain notes for this batch:**
- **Standards bodies (AES, IEC, ISO, ITU-R, EBU, ANSI, NIST, IEEE, CTA, TIA, EIA, FCC):** author as the organization — what it is, scope, and one or two audio-relevant standards it owns (e.g. AES3/AES67, BS.1770, EBU R128, CTA-2034). Do NOT invent standard numbers; cite the body's own documentation.
- **Compliance/marks (CE, WEEE, UL, CSA, TÜV, FCC Equipment Authorization, EMC/ESD/RF-emissions testing, QMS):** regulatory — cite the directive/standard, never a blog. Safety framing where relevant.
- **HRTF, dialnorm, RF multicoupler, frequency diversity:** established technical terms — define precisely with the standard correlate.
- **Broadcast/FCC terms** are regulatory: cite 47 CFR Part 73/11 and manufacturer docs.

**Deadline: 15 August, zero placeholders.** Checkpoint every packet to disk. When done/paused, hand back `authored_OUTPUT/`, `committee_OUTPUT/`, `corrected_OUTPUT/`, and `COMPLETION_NOTES.md`.

---
⇧ END OF PROMPT ⇧
