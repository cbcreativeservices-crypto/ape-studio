# AP&E Glossary — Machine B · Additional Missing-Shorthand Terms (2026-07-25)

**177 Booth-approved terms · 20 packets · 1416 fields.** NEW terms — author all 8 fields from scratch. Machine A inserts on return; you never touch the DB.

## Contents
```
HANDOFF_PROMPT.md   <- start here
README.md
MANIFEST.json       <- packets: group, primary topic, difficulty, counts
ASSIGNED_TERM_IDS.txt <- the term IDs (never change an id)
briefs/  tools/check_readability.py
packets/  add_01..add_20.json
authored_OUTPUT/  committee_OUTPUT/  corrected_OUTPUT/
```

## Packets
| # | Packet | Terms | Primary topic |
|---|---|---|---|
| 1 | add_01_radio_onair | 27 | Broadcast / Radio Production & Air Chain |
| 2 | add_02_radio_imaging | 4 | Broadcast / Radio Production & Air Chain |
| 3 | add_03_radio_traffic | 5 | Broadcast / Radio Production & Air Chain |
| 4 | add_04_radio_dayparts | 4 | Broadcast / Radio Production & Air Chain |
| 5 | add_05_radio_scheduling | 13 | Broadcast / Radio Production & Air Chain |
| 6 | add_06_radio_callin | 5 | Broadcast / Radio Production & Air Chain |
| 7 | add_07_radio_transmission | 10 | Broadcast / Radio Production & Air Chain |
| 8 | add_08_vinyl_setup | 15 | HiFi Consumer Audio |
| 9 | add_09_dac_clocking | 10 | Preamp & Converter Engineering |
| 10 | add_10_cables_power | 9 | Cables & Wiring |
| 11 | add_11_tubes | 6 | Vacuum Tubes |
| 12 | add_12_room_measurement | 14 | Audio Measurement & Optimization |
| 13 | add_13_headphones | 6 | HiFi Consumer Audio |
| 14 | add_14_descriptors | 17 | Tonal & Timbre Descriptors |
| 15 | add_15_general | 2 | HiFi Consumer Audio |
| 16 | add_16_brand_features | 3 | Dynamics Processing |
| 17 | add_17_standards_bodies | 12 | Industry Foundations |
| 18 | add_18_compliance_certs | 10 | Manufacturing & Production |
| 19 | add_19_metrology_qa | 1 | Measurement Fundamentals & Metering |
| 20 | add_20_spatial_rf_broadcast_gaps | 4 | Psychoacoustics |

Topic/difficulty pre-assigned by Machine A; if a term is clearly misfiled, flag it in COMPLETION_NOTES — don't silently move it.

Batches folded in: 150 shorthand/alias terms (packets 1–16) + 27 standards/compliance/gap terms (packets 17–20, incl. AES, IEC, ISO, ITU-R, IEEE, FCC, CE, WEEE, UL, CSA, TÜV, EMC/ESD testing, QMS, Calibration Traceability, HRTF, dialnorm, RF Multicoupler, Frequency Diversity).