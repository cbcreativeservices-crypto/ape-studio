# AP&E Glossary — Machine B · Additional Missing-Shorthand + Standards + Brand Lexicon (2026-07-25)

**197 Booth-approved terms · 22 packets · 1576 fields.** NEW terms — author all 8 fields from scratch. Machine A inserts on return; you never touch the DB.

## Packets
| # | Packet | Terms | Primary topic |
|---|---|---|---|
| 1 | add_01_radio_onair | 27 | Broadcast / Radio Production & Air Chain |
| 2 | add_02_radio_imaging | 4 | Broadcast / Radio Production & Air Chain |
| 3 | add_03_radio_traffic | 5 | Broadcast / Radio Production & Air Chain |
| 4 | add_04_radio_dayparts | 4 | Broadcast / Radio Production & Air Chain |
| 5 | add_05_radio_scheduling | 13 | Broadcast / Radio Production & Air Chain |
| 6 | add_06_radio_callin | 5 | Broadcast / Radio Production & Air Chain |
| 7 | add_07_radio_transmission | 10 | Broadcast / Radio Production & Air Chain |
| 8 | add_08_vinyl_setup | 15 | HiFi Consumer Audio |
| 9 | add_09_dac_clocking | 10 | Preamp & Converter Engineering |
| 10 | add_10_cables_power | 9 | Cables & Wiring |
| 11 | add_11_tubes | 6 | Vacuum Tubes |
| 12 | add_12_room_measurement | 14 | Audio Measurement & Optimization |
| 13 | add_13_headphones | 6 | HiFi Consumer Audio |
| 14 | add_14_descriptors | 17 | Tonal & Timbre Descriptors |
| 15 | add_15_general | 2 | HiFi Consumer Audio |
| 16 | add_16_brand_features | 3 | Dynamics Processing |
| 17 | add_17_standards_bodies | 12 | Industry Foundations |
| 18 | add_18_compliance_certs | 10 | Manufacturing & Production |
| 19 | add_19_metrology_qa | 1 | Measurement Fundamentals & Metering |
| 20 | add_20_spatial_rf_broadcast_gaps | 4 | Psychoacoustics |
| 21 | add_21_brand_protools | 8 | DAW Fundamentals & Session Management |
| 22 | add_22_brand_yamaha | 12 | Industry Foundations |

Folded in: 150 shorthand/alias (1–16) + 27 standards/compliance/gap (17–20) + 20 Pro Tools & Yamaha lexicon (21–22).
Topic/difficulty pre-assigned; if a term is clearly misfiled, flag it in COMPLETION_NOTES — don't silently move it.
Never change an `id` or `term`. List fields stay JSON arrays. No citations inside field text — sources go in the `sources` array.