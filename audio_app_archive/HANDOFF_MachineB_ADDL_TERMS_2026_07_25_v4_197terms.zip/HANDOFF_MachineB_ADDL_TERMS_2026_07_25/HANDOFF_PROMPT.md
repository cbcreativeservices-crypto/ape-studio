# ⇩ PASTE THIS INTO MACHINE B TO AUTHOR THE ADDITIONAL (MISSING-SHORTHAND) TERMS ⇩

---

**Standalone batch: 197 terms · 1,576 fields · 22 packets.** Common-shorthand / alias / standards / brand-lexicon terms an audit found missing from the glossary (e.g. *Outcue*, *Deadwax*, *Clockwheel*, *Headstage*, *Spinorama*, *HRTF*, *AES*, *FCC*, *CE Marking*, *dialnorm*, *Pro Tools*, *NS-10*, *DX7*). Prof. Booth approved this exact list. Do **not** add, drop, or re-scope terms.

These terms do **not exist in the database yet.** You AUTHOR them from scratch — every field in each term's `empty_fields` (all 8). Machine A INSERTS your returned output into production (backup + checksum). **You never write to any database.** Never change a term's `id` (Machine A inserts on that id) or its `term`.

Read `README.md`, then run our standard four-step pipeline on every term:

1. **Author** — `briefs/AUTHORING_BRIEF.md`. Author all 8 fields. Keep `id`, `term`, `topic`, `topic_id`, `difficulty`, `cross_list_topics` exactly as given. Honor each `authoring_note`.
2. **Committee (mandatory)** — all three experts over every term: `BRIEF_COMMON.md` + `BRIEF_AUDIO.md` + `BRIEF_COGNITION.md` + `BRIEF_LANGUAGE.md`.
3. **Corrections** — `briefs/EDITOR_BRIEF.md`, web-verifying each technical fix.
4. **Readability gate (do not skip)** — `python3 tools/check_readability.py corrected_OUTPUT`, then `briefs/REWRITE_BRIEF.md` until it passes.

**The four rules that override everything:**
- **Never author without the committee.** Every term, all three experts.
- **No placeholders, ever.** `(definition pending)` / `(pending)` = not written. Cannot confirm from a qualifying source? Leave blank and flag.
- **Source quality.** Wikipedia/Reddit/forums/blogs/SEO/AI text/vendor *marketing* do NOT count. Use standards bodies (FCC Part 73/11, AES, IEC, ISO, ITU-R BS.1770/EBU R128, IEEE, SMPTE), manufacturer *technical* docs, or recognised professional texts. ≥2 per fact, ≥3 for safety/regulatory.
- **`plain_english` ≤ grade 9** — 14-year-old, sentences ≤ 20 words. Run the gate.

**Domain notes:**
- **Standards bodies** (packet 17): author as the organization — what it is, scope, one or two audio-relevant standards it owns (AES3/AES67, BS.1770, EBU R128, CTA-2034). Never invent standard numbers.
- **Compliance/marks** (packet 18): cite the directive/standard; safety framing where relevant.
- **Brand terms** (packets 21–22, Pro Tools & Yamaha): these are trademarks that are now part of the audio lexicon — define neutrally and factually (what it is, why it matters, era). Use the maker's technical documentation, not marketing superlatives. Note trademark ownership (Avid; Yamaha). Do NOT editorialize ("best", "legendary") — describe why it became a reference.
- **Brand consolidations:** "Yamaha Motif / Montage", "Yamaha PM Series (PM5D / Rivage PM)", "Yamaha 02R / 01V", "Edit Modes (Shuffle/Slip/Spot/Grid)" — one entry each covering the line/set.

**Deadline: 15 August, zero placeholders.** Checkpoint every packet to disk. Hand back `authored_OUTPUT/`, `committee_OUTPUT/`, `corrected_OUTPUT/`, `COMPLETION_NOTES.md`.

---
⇧ END OF PROMPT ⇧
