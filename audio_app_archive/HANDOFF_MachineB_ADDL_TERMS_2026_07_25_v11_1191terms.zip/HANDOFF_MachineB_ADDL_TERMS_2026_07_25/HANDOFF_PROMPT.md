

**EQUATION ENTRIES (`eq_*`):** verify formula_symbolic, rewrite formula_words + legend, author 8 fields. App swaps symbolic<->worded on tap; DB has formula_symbolic/formula_words columns — Machine A populates on insert.
