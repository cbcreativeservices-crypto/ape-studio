# AP&E Glossary — Machine B · Additional Terms (1191 terms)

**1191 terms · 107 packets · 9528 fields.** Includes 196 Phase-50 EQUATIONS (`eq_*`, formula_symbolic+formula_words, click-swap) + math/physics/wave/acoustics/architectural phases. Never change id/term; sources in `sources` array; follow BRAND/TRADEMARK + EQUATION rules in HANDOFF_PROMPT.md.