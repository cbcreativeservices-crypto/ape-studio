# ⁩ PASTE THIS INTO MACHINE B TO AUTHOR THE ADDITIONAL TERMS ⁩

---

**Standalone batch: 469 terms · 3752 fields · 49 packets.** Missing shorthand/alias + standards/compliance + brand-lexicon terms an audit found absent from the glossary. Prof. Booth approved this exact list across several passes (shorthand; standards; Pro Tools/Yamaha; Ableton; Sony; Solid State Logic; Allen & Heath). Do **not** add, drop, or re-scope terms.

These terms do **not exist in the database yet.** You AUTHOR them from scratch — every field in each term's `empty_fields` (all 8). Machine A INSERTS your returned output into production (backup + checksum). **You never write to any database.** Never change a term's `id` or its `term`.

Read `README.md`, then run our standard four-step pipeline on every term:
1. **Author** — `briefs/AUTHORING_BRIEF.md`. Author all 8 fields. Keep `id`, `term`, `topic`, `topic_id`, `difficulty`, `cross_list_topics` exactly as given. Honor each `authoring_note`.
2. **Committee (mandatory)** — all three experts over every term.
3. **Corrections** — `briefs/EDITOR_BRIEF.md`, web-verifying each fix.
4. **Readability gate (do not skip)** — `python3 tools/check_readability.py corrected_OUTPUT`, then `briefs/REWRITE_BRIEF.md` until it passes.

**Four rules that override everything:** never author without the committee · no placeholders ever · strict sourcing (standards bodies / manufacturer *technical* docs / recognised texts; ≥2 per fact, ≥3 safety) · `plain_english` ≤ grade 9 (run the gate).

**BRAND / TRADEMARK RULE (this batch is heavy with Pro Tools, Yamaha, Ableton, Sony, SSL, Allen & Heath):**
- Define trademarks **neutrally and factually** from the maker's own technical documentation — **never marketing superlatives** ("legendary", "the best", "revolutionary", "warmth you can feel").
- State plainly: what it is, what it does, where the user meets it, the company that owns it, era/context. For an *algorithm / format / architecture / mode* (LDAC, ATRAC, 360 Reality Audio, SuperAnalogue, VHD, XCVI, gigaACE, DEEP, Warp Modes), give the technical mechanism at grade level — not the ad copy.
- The *name* is proprietary; the underlying *method* often is not (e.g. SSL "Bus Compressor" is a VCA bus comp; A&H "Dyn8" is dynamic EQ + multiband). Say so — credit the concept generically, tag the branded name to the maker.
- Note shared/older formats honestly (DSD/SACD were Sony–Philips; PAFL predates any one maker).
- File formats / model numbers (ALS, AMXD, ATRAC, DX168, ME-1, UF8): emphasize what it is and the troubleshooting/interchange implication.

**Deadline: 15 August, zero placeholders.** Checkpoint every packet to disk. Hand back `authored_OUTPUT/`, `committee_OUTPUT/`, `corrected_OUTPUT/`, `COMPLETION_NOTES.md`.

---
⁩ END OF PROMPT ⁩
