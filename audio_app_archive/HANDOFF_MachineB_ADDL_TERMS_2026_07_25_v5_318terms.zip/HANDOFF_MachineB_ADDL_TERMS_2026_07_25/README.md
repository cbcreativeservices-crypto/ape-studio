# AP&E Glossary — Machine B · Additional Terms (318 terms, 2026-07-25)

**318 Booth-approved terms · 31 packets · 2544 fields.** NEW terms — author all 8 fields. Machine A inserts on return; you never touch the DB.

## Packets
| # | Packet | Terms | Primary topic |
|---|---|---|---|
| 1 | add_01_radio_onair | 27 | Broadcast / Radio Production & Air Chain |
| 2 | add_02_radio_imaging | 4 | Broadcast / Radio Production & Air Chain |
| 3 | add_03_radio_traffic | 5 | Broadcast / Radio Production & Air Chain |
| 4 | add_04_radio_dayparts | 4 | Broadcast / Radio Production & Air Chain |
| 5 | add_05_radio_scheduling | 13 | Broadcast / Radio Production & Air Chain |
| 6 | add_06_radio_callin | 5 | Broadcast / Radio Production & Air Chain |
| 7 | add_07_radio_transmission | 10 | Broadcast / Radio Production & Air Chain |
| 8 | add_08_vinyl_setup | 15 | HiFi Consumer Audio |
| 9 | add_09_dac_clocking | 10 | Preamp & Converter Engineering |
| 10 | add_10_cables_power | 9 | Cables & Wiring |
| 11 | add_11_tubes | 6 | Vacuum Tubes |
| 12 | add_12_room_measurement | 14 | Audio Measurement & Optimization |
| 13 | add_13_headphones | 6 | HiFi Consumer Audio |
| 14 | add_14_descriptors | 17 | Tonal & Timbre Descriptors |
| 15 | add_15_general | 2 | HiFi Consumer Audio |
| 16 | add_16_brand_features | 3 | Dynamics Processing |
| 17 | add_17_standards_bodies | 12 | Industry Foundations |
| 18 | add_18_compliance_certs | 10 | Manufacturing & Production |
| 19 | add_19_metrology_qa | 1 | Measurement Fundamentals & Metering |
| 20 | add_20_spatial_rf_broadcast_gaps | 4 | Psychoacoustics |
| 21 | add_21_brand_protools | 8 | DAW Fundamentals & Session Management |
| 22 | add_22_brand_yamaha | 12 | Industry Foundations |
| 23 | add_23_ableton_live | 44 | DAW: Ableton Live |
| 24 | add_24_ableton_files | 7 | Audio File Formats & Media |
| 25 | add_25_sony_immersive | 9 | Immersive Formats & Delivery |
| 26 | add_26_sony_dawskills | 13 | DAW Skills |
| 27 | add_27_sony_affmt | 8 | Audio File Formats & Media |
| 28 | add_28_sony_htheater | 6 | Home Theater & Residential AV |
| 29 | add_29_sony_hifi | 24 | HiFi Consumer Audio |
| 30 | add_30_sony_rf | 3 | RF Wireless Systems |
| 31 | add_31_sony_lstrans | 7 | Loudspeaker / Transducer Engineering |

Folded in: shorthand/alias (1–16) · standards/compliance/gaps (17–20) · Pro Tools & Yamaha (21–22) · Ableton (23–24) · Sony (25–31).
Never change an `id` or `term`. List fields stay JSON arrays. No citations inside field text — sources go in `sources`. Follow the BRAND/TRADEMARK RULE in HANDOFF_PROMPT.md.