# ⇩ PASTE THIS INTO MACHINE B TO AUTHOR THE ADDITIONAL TERMS ⇩

---

**Standalone batch: 318 terms · 2,544 fields · 31 packets.** Missing shorthand/alias + standards/compliance + brand-lexicon terms an audit found absent from the glossary. Prof. Booth approved this exact list across several passes. Do **not** add, drop, or re-scope terms.

These terms do **not exist in the database yet.** You AUTHOR them from scratch — every field in each term's `empty_fields` (all 8). Machine A INSERTS your returned output into production (backup + checksum). **You never write to any database.** Never change a term's `id` or its `term`.

Read `README.md`, then run our standard four-step pipeline on every term:
1. **Author** — `briefs/AUTHORING_BRIEF.md`. Author all 8 fields. Keep `id`, `term`, `topic`, `topic_id`, `difficulty`, `cross_list_topics` exactly as given. Honor each `authoring_note`.
2. **Committee (mandatory)** — all three experts over every term.
3. **Corrections** — `briefs/EDITOR_BRIEF.md`, web-verifying each fix.
4. **Readability gate (do not skip)** — `python3 tools/check_readability.py corrected_OUTPUT`, then `briefs/REWRITE_BRIEF.md` until it passes.

**Four rules that override everything:** never author without the committee · no placeholders ever · strict sourcing (standards bodies / manufacturer *technical* docs / recognised texts; ≥2 per fact, ≥3 safety) · `plain_english` ≤ grade 9 (run the gate).

**BRAND / TRADEMARK RULE (this batch is heavy with them — Pro Tools, Yamaha, Ableton, Sony):**
- Define trademarks **neutrally and factually** from the maker's own technical documentation and manuals — **never marketing superlatives** ("legendary", "the best", "revolutionary").
- State plainly: what it is, what it does, where the user meets it, the company that owns it, and era/context. For an *algorithm/format/mode* (LDAC, ATRAC, 360 Reality Audio, Warp Modes, ACIDized Loop), give the technical mechanism at grade level, not the ad copy.
- For Sony spatial/codec claims, cite Sony technical documentation; note where a format is shared (e.g. DSD/SACD were Sony–Philips) rather than implying sole Sony ownership.
- Ableton device names (Simpler, Operator, Meld, Corpus, Roar, etc.): index under Ableton but explain the underlying synthesis/effect method generically; the *name* is proprietary, the *method* often isn't — say so.
- Ableton/Sony **file formats** (ALS, ALP, ALC, ADG, AGR, ASD, AMXD; ATRAC, Wave64/W64, SFK, PCA): emphasize what the file contains and the troubleshooting/interchange implications.

**Deadline: 15 August, zero placeholders.** Checkpoint every packet to disk. Hand back `authored_OUTPUT/`, `committee_OUTPUT/`, `corrected_OUTPUT/`, `COMPLETION_NOTES.md`.

---
⇧ END OF PROMPT ⇧
