

**EQUATION ENTRIES (`eq_*`):** verify formula_symbolic, write formula_words+legend, author 8 fields; app tap-swaps symbolic<->worded; DB has formula columns.
