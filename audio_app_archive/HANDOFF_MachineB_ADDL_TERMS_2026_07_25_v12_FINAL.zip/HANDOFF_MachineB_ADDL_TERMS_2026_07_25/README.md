# AP&E Glossary — Machine B · Additional Terms (1253 terms)

**1253 terms · 112 packets · 10024 fields.** See HANDOFF_PROMPT.md (BRAND/TRADEMARK + EQUATION rules). 196 equation entries carry formula_symbolic/formula_words.