# HANDOFF — Computer C · SOUND VISUALIZATION & SCIENTIFIC ACOUSTICS (2026-08-02)

**You are Computer C.** Author the **1,664 net-new terms** in `ComputerC_SOUNDVIZ_terms.csv` — new
glossary rows (**INSERT**). Everything you need is in this package: the terms CSV, the full toolkit
(`tools/`), and the author + committee briefs (`briefs/`). You do **not** write to the database — you
return a corrected merge payload to Machine A (sole DB writer), which creates topic rows and assigns
`achievement_id` at ingest.

`source_batch = SOUNDVIZ_2026_08_02`. These terms were **already deduplicated against the live
glossary** — every one is net-new by headword.

## This package
- `ComputerC_SOUNDVIZ_terms.csv` — the 1,664 terms. Columns: `term, subject, landing_topic, tier,
  concept_hint, status, source_batch`.
- `tools/` — `build_packets.py build_review.py verify.py fk_gate.py aggregate_suggestions.py
  verify_committee.py build_delivery.py`.
- `briefs/` — `AUTHORING_GUIDE_shared.md` (read first), `AUTHORING_BRIEF_c.md`, `COMMITTEE_BRIEF_c.md`.

## CSV columns
| column | meaning |
|---|---|
| `term` | headword — **frozen** |
| `subject` | the branch (one of 16, below) |
| `landing_topic` | the sub-topic — **frozen**; `build_packets.py` groups packets by it |
| `tier` | build priority (see below) — advisory, not a field to author |
| `concept_hint` | short "glossary-angle" pointer carried from the source research (present for ~1,000 terms). A **disambiguation pointer only — do NOT paraphrase it** into field text; author originally |
| `status` | `NEW` |
| `source_batch` | `SOUNDVIZ_2026_08_02` |

No `id` column → `build_packets.py` runs in **INSERT mode** and mints stable ids in Computer C's own
namespace (`apne.computerC.glossary.2026`). Author all 8 fields + `difficulty` for every term.

## Branches (subjects) and build tiers
**Tier 1 — build (1,384).** High-confidence, well-attested audio/engineering/science fields:
Sound Visualization & Acoustic Imaging · Sound Physics, Measurement & Acoustic Quantities · Advanced
Acoustic Imaging & Sound-Field Reconstruction · Data Sonification & Auditory Display · Chemical &
Molecular Acoustics · Geologic & Seismoacoustics · **Bioacoustics & Ecoacoustics** · **Underwater
Acoustics & Sonar** · **Aeroacoustics & Flow-Induced Sound** · **Ultrasonics, NDT & Industrial
Inspection** · Medical, Hearing & Clinical Acoustics · Forensic Audio & Investigative Acoustics.
(The four in **bold** are the tightest / most standardized — safest to start.)

**Tier 2 — interpretive (280).** Humanities / cross-field, where terms are more context-dependent:
Anthropology & Sound Studies · Archaeological & Heritage Acoustics · Astronomical & Cosmological
Acoustics · Cross-Disciplinary Sonic Sensing. **Author only what you can confidently source; apply
the flag-don't-guess rule aggressively** here — a `FLAG-FOR-REVIEW` is the correct output for a term
that has no authoritative, definable meaning. Expect a higher flag rate in Tier 2 than Tier 1.

## Pipeline (full detail in briefs/ + tools/)
1. `python tools/build_packets.py ComputerC_SOUNDVIZ_terms.csv` → `packets/gNN.json` (grouped by
   `landing_topic`, ids minted in C namespace).
2. **Author** each packet → `authored_OUTPUT/gNN.json` per `briefs/AUTHORING_BRIEF_c.md` (all 8 fields
   + difficulty; formula_symbolic/formula_words only for equation/quantity terms).
3. `python tools/verify.py all` (0 errors) → `python tools/fk_gate.py all` (plain_english ≤ grade 9).
4. `python tools/build_review.py` → committee (4 experts × ~35-term groups per
   `briefs/COMMITTEE_BRIEF_c.md`) → `python tools/verify_committee.py` (0 errors).
5. `python tools/aggregate_suggestions.py` → apply editor corrections (never change id/term/difficulty;
   keep a pre-correction snapshot) → re-run verify + fk_gate.
6. `python tools/build_delivery.py SOUNDVIZ_2026_08_02` → `deliverable/DELIVERY_MachineA_SOUNDVIZ_2026_08_02/`
   with `ComputerC_committee_reviewed.csv`, `merge_payload.json/.ndjson`, and the reports
   (difficulty, legal-citations, term-duplicate, flagged-contested, CHECKSUMS). Zip + send to Machine A.

## Rules that matter most here (from the shared guide)
- **≥2 authoritative sources per fact (≥3 if safety-critical).** Standards bodies (IEC/ISO/ANSI-ASA/
  AES/IEEE/ITU/SMPTE-EBU), manufacturer technical docs, recognized professional/peer-reviewed texts.
  Wikipedia/forums/blogs/marketing are pointers only — never cited, never counted.
- **No verbatim copying**; original expression in every field. Where a term derives from a standard,
  name it as plain fact — no parenthetical citations inside field text.
- **plain_english** at Flesch-Kincaid grade ≤ 9, sentences ≤ 20 words; all other fields stay fully
  technical.
- **category = the row's `landing_topic`, verbatim.** Do not re-topic.
- **Safety:** ultrasound/HIFU, cavitation, industrial/NDT, sonar, aero and any hazard term gets an
  `UNSAFE:`-prefixed entry in `common_mistakes`. Don't invent numeric limits.
- **Flag, don't guess** — `confidence:"FLAG-FOR-REVIEW"`, empty fields, reason in `flags`. Essential
  for Tier 2.

## Machine A / Booth note
16 subjects × their sub-topics are **provisional** — Machine A creates the topic rows and assigns
`achievement_id` at ingest; final topic consolidation is Booth's call. Deliver as INSERT keyed on the
minted id.
