# COMMITTEE REVIEW BRIEF — Computer C

You review **one group** (`review_packets/group_NN.json`, ~35 fully-authored terms) as **all four
independent experts**, and emit **four files**:
`committee_OUTPUT/audio_NN.json`, `cognition_NN.json`, `language_NN.json`, `legal_NN.json`.
Each file contains **exactly one review object per term, in packet order** — no term skipped, none
added. Review each entry **through that expert's lens only**.

## SHARED RULES (all four experts)
- **Bias to OK.** Most terms should come back `"OK"` with empty suggestions. A healthy result is
  **~90–99% OK**. Do NOT manufacture issues or nitpick. Quality of the few real flags beats volume.
- **Coverage:** output count MUST equal the group's term count, same order, matching `id`. (Verified
  by `verify_committee.py` — a miscount fails the gate.)
- **Severity ladder (strict):**
  - **High** = a factual/technical error, unsafe guidance, self-contradiction, or substantial
    copyright infringement that would mislead or expose the product.
  - **Medium** = a real accuracy / safety / comprehension / originality improvement a professional
    would actually make.
  - **Low** = a genuine clarity/grammar problem or a missing/ill-fitting difficulty tag — not a style
    preference.
- **Do NOT flag house style:** list-item capitalization, serial/terminal punctuation, and hyphenation
  are intentional per-entry conventions, not errors.
- **Source-quality rule:** Wikipedia, Reddit, forums, Quora, blogs, SEO/content-farm pages, AI text,
  and vendor marketing **do not count** — pointers only, never cited, never corroboration. Any source
  you cite for a Medium/High flag must be a standards body, manufacturer technical/service doc, or a
  recognised professional text / peer-reviewed source. **≥2 sources per fact, ≥3 for safety-critical.**

## THE FOUR EXPERTS
1. **audio** — senior audio systems engineer. Lens: **TECHNICAL ACCURACY.** Wrong facts/specs/units/
   standard names/model names, outdated or **unsafe** practice, technically wrong related_terms or
   scenarios. For **every Medium/High** flag you MUST web-verify the correct fact first and put the
   verified fact + its authoritative source **inside the `issue` text**. Safety-critical errors
   (mains/power, levels/exposure, rigging/loads) = **High**.
2. **cognition** — learning scientist (technical/vocational ed). Lens: **DOES THIS TEACH WELL at the
   stated difficulty?** Cognitive load, scaffolding, unstated prerequisites, analogy quality, whether
   `common_mistakes` target real misconceptions, whether the `difficulty` tag fits. If a difficulty
   tag is missing or clearly wrong, propose the right level via a suggestion with `"field":"difficulty"`.
   Does not judge raw technical accuracy unless it creates a learning trap.
3. **language** — technical editor + plain-language communicator. Lens: **CLARITY & CORRECT WRITING.**
   Grammar, syntax, wrong words, real ambiguity, run-ons, **undefined jargon in `plain_english`**,
   duplicate list items. Give a concrete rewrite for anything flagged. Never change technical meaning.
   (Reading level is gated programmatically — flag only genuine clarity faults, not FK arithmetic.)
4. **legal** — IP researcher (copyright, trademark, patent). **Two distinct jobs, see below.** Does
   not judge technical accuracy, pedagogy, or style.

## THE LEGAL EXPERT'S TWO JOBS
**Job 1 — Copyright / originality (feeds corrections).** For every term, check each field for text
**copied verbatim or closely paraphrased** from a copyrightable source (dictionary, encyclopedia incl.
Wikipedia, textbook, manufacturer manual, standards prose, another glossary). Facts, spec values, a
standard's exact defined term, short factual phrases, and the headword are **not** infringement — do
not flag those. Flag distinctive sentences/analogies/multi-clause definitions that track a specific
source's wording; quote the overlapping span in `issue`, name the suspected source, and give an
original rewrite in `suggestion`. Severity: High = substantial verbatim copying; Medium = close
paraphrase to reword; Low = minor echo. **Bias to OK** — multi-source authored terms are usually
already original. These go in the normal `suggestions` array.
**Job 2 — Mark / citation flagging (separate report, applied AFTER review).** List every term, product
name, brand, technology, or standard carrying a trademark / registered mark / copyright / attribution
requirement, so the correct ® ™ © / standard attribution can be added later. **Do NOT edit field text
for this.** Put each in the top-level `legal_citations` array with the **web-verified owner**. Mark
`confidence:"unverified"` if you cannot confirm the owner to an authoritative source.

## OUTPUT FORMAT — one JSON file per expert (valid JSON, parses cleanly)
```json
{ "expert": "audio|cognition|language|legal", "group": <n>,
  "reviews": [
    {"id":"<uuid>", "term":"<term>", "verdict":"OK|MINOR|NEEDS_REVISION",
     "suggestions": [
       {"field":"<affected field>", "severity":"High|Medium|Low",
        "issue":"<what is wrong; for Med/High technical or copyright include the web-verified fact/source>",
        "suggestion":"<concrete fix / original rewrite>"}
     ]}
  ]
  // legal file ONLY — additional top-level array (Job 2):
  , "legal_citations": [
     {"id":"<uuid>","term":"<term>","mark":"<name as it appears>",
      "mark_type":"registered_trademark|trademark|copyright|standard_or_patent_attribution",
      "symbol":"®|™|©|(cite)","owner":"<verified owner>","confidence":"verified|unverified",
      "where":"<where attribution applies>","note":"<short note>"}
  ]
}
```
- `verdict`: `OK` = no changes (empty `suggestions`). `MINOR` = only Low/Medium suggestions.
  `NEEDS_REVISION` = at least one High.
- The **legal file always includes `legal_citations`** (use `[]` if none).
- Every non-legal expert omits `legal_citations`.
Validate each file parses before finishing. Aim for the ~90–99% OK bias — flag only what's real.
