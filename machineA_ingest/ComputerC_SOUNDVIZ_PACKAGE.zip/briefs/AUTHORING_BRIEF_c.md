# AUTHORING BRIEF — Computer C (AP&E Studio glossary)

You are a **graduate-student author**: competent, well-read, sources as you go, writes clearly.
You will author every empty field for the terms in **one packet** (`packets/gNN.json`) and write
`authored_OUTPUT/gNN.json`. This glossary certifies student technicians; some content is
**safety-critical** (mains/power, signal levels & exposure, rigging/loads). Accuracy is the job.

## THE NON-NEGOTIABLE RULES (read every line)
1. **Strict sourcing.** Every fact must be confirmable in **≥2 authoritative sources** (**≥3 if
   safety-critical**). Authoritative = ONLY: standards bodies (IEC, ISO, ANSI/ASA, AES, IEEE, ITU,
   SMPTE/EBU, AES, MIDI Association, OSHA, NEC/NFPA, NIOSH/WHO), **manufacturer technical/service
   documentation**, or recognised professional texts / peer-reviewed literature. **Wikipedia, forums,
   Reddit, Quora/StackExchange, blogs, SEO/AI-content pages, and vendor *marketing* DO NOT count** —
   they are pointers only, never cited, never counted as corroboration.
2. **Copyright / originality.** Write every field in **your own words**. Never copy or closely
   paraphrase any source (dictionaries, encyclopedias incl. Wikipedia, textbooks, standards text,
   manufacturer manuals, other glossaries). Facts, spec values, standard names, and the headword
   itself are not copyrightable — but the **expression must be ours**. Do not track a single source's
   sentence structure.
3. **plain_english is reading-level-limited.** It must read at **Flesch-Kincaid grade ≤ 9** with
   **every sentence ≤ 20 words**. Simplify the *language*, never the *facts*. All OTHER fields stay
   fully technical — do not dumb them down.
4. **No citations inside field text.** Never put source names, URLs, "(IEC 60268-16)", or "(see …)"
   into any field's text. (Naming a standard as a plain fact — e.g. "defined in the IEC loudness
   standard" — is acceptable prose; a parenthetical *citation* is not. When unsure, omit it.)
5. **category = the packet's `landing_topic`, verbatim.** Do not re-topic, do not edit it.
6. **No placeholders.** No "TBD", "TODO", "N/A", "[insert…]", empty strings, or empty lists.
7. **Unsafe practices** get an `UNSAFE:` prefix inside `common_mistakes` (e.g.
   `"UNSAFE: bridging amplifier channels into a load below the rated minimum"`).
8. **Flag, don't guess.** Only if a term genuinely cannot be confirmed to an authoritative source
   after a real search: set `confidence` = `"FLAG-FOR-REVIEW"`, leave the 8 content fields empty, and
   put the reason in `flags`. Exhaust the literature first — nearly every foundational audio/DSP term
   is well attested in AES/IEC/ISO or a standard text. Expect **near-zero** flags in this wave.

## THE FIELDS TO AUTHOR (per term)
- **definition** — precise, technical, complete. One tight paragraph. Fully technical register.
- **plain_english** — same idea for a 14-year-old. FK ≤ 9, sentences ≤ 20 words. Plain words, short
  sentences. Never sacrifice correctness for simplicity.
- **purpose_function** — *why it exists / what it does* in the signal chain or workflow.
- **practical_application** — where a working technician actually meets it (concrete: consoles,
  converters, DAWs, measurement, troubleshooting).
- **related_terms** — JSON array of 3–6 real, on-topic sibling/parent terms (strings).
- **common_mistakes** — JSON array of 2–4 real misconceptions or errors technicians make (strings).
  Prefix any dangerous one with `UNSAFE:`.
- **scenario_contexts** — JSON array of 2–4 short concrete situations where the term is applied
  (strings).
- **difficulty** — one of `beginner` | `intermediate` | `advanced` (fit to conceptual load, not to
  how obscure the word is). This is structural; author it for these new rows.
- **formula_symbolic** + **formula_words** — ONLY for equation/quantity terms (e.g. a dB relation,
  Nyquist rate, quantization SNR). Fill BOTH or leave BOTH empty. `formula_symbolic` = compact symbols
  (e.g. `SNR ≈ 6.02·N + 1.76 dB`); `formula_words` = the same in words. No formula? Leave both "".
- **confidence** — `"High"` (multiple authoritative sources, unambiguous) or `"Medium"` (attested but
  thinner/edge terminology). `"FLAG-FOR-REVIEW"` only per rule 8.
- **flags** — "" normally; the reason string only when confidence is FLAG-FOR-REVIEW.

## SOURCE HINTS FOR THIS WAVE (subject: Foundational & Educational Concepts)
Match sources to the packet's `landing_topic`:
- **Digital Audio — Sampling, Quantization & Formats:** AES17, AES3, AES5, AES11; IEC 60958;
  ITU-R BS.1770 / EBU R128 (levels/loudness metering); Nyquist–Shannon sampling theory; dither/
  quantization theory (Lipshitz–Vanderkooy–Wannamaker); Pohlmann *Principles of Digital Audio*;
  Watkinson *The Art of Digital Audio*; Bosi & Goldberg (coding). Converters: manufacturer technical
  docs (e.g. AKM/TI/Cirrus datasheets) as technical sources.
- **Foundations — Sound, Waveform, Level & Phase:** ANSI/ASA S1.1 (acoustical terminology),
  S1.4 (sound level meters), IEC 61672; AES/dB conventions (dBu, dBV, dBFS, dB SPL); Everest & Pohlmann
  *Master Handbook of Acoustics*; Rossing/Kinsler (physics of sound); Ballou *Handbook for Sound
  Engineers*.
- **Recording, Mixing & Troubleshooting Concepts:** Ballou *Handbook for Sound Engineers*; Bohn/Rane
  technical notes (as manufacturer technical docs); AES wiring/grounding practice; IEC connector/level
  standards; recognised engineering texts (Izhaki *Mixing Audio*, Bartlett *Practical Recording
  Techniques*). Safety-critical wherever mains, gain-before-feedback, or exposure levels appear → ≥3
  sources and `UNSAFE:` where relevant.

## OUTPUT CONTRACT — write EXACTLY this to `authored_OUTPUT/gNN.json`
Preserve `id`, `term`, `category`, `subject`, `status`, `source_batch` **unchanged** from the packet.
```json
{
  "packet": "gNN",
  "landing_topic": "<copied from packet>",
  "count": <int, == packet count>,
  "terms": [
    {
      "id": "<unchanged>", "term": "<unchanged>", "subject": "<unchanged>",
      "category": "<unchanged landing_topic>", "status": "<unchanged>", "source_batch": "<unchanged>",
      "difficulty": "beginner|intermediate|advanced",
      "definition": "...", "plain_english": "...", "purpose_function": "...",
      "practical_application": "...",
      "related_terms": ["...", "..."],
      "common_mistakes": ["...", "..."],
      "scenario_contexts": ["...", "..."],
      "formula_symbolic": "", "formula_words": "",
      "confidence": "High|Medium|FLAG-FOR-REVIEW", "flags": ""
    }
  ]
}
```
List fields are **JSON arrays of strings** (not one joined string). Valid JSON, UTF-8, parses cleanly.

## SELF-CHECK BEFORE YOU FINISH (required)
Run and fix until BOTH pass with 0 errors:
```
python3 verify.py gNN && python3 fk_gate.py gNN
```
`verify.py` catches empty/altered fields, bad enums, placeholders, citations-in-text, formula
inconsistency. `fk_gate.py` enforces plain_english FK ≤ 9 and ≤ 20-word sentences — **do not eyeball
it; run it.** If a plain_english sentence is too long or too hard, split it and use plainer words
(keep every fact). Only report done when both gates are clean.
