#!/usr/bin/env python3
"""Programmatic readability gate for plain_english.
Fail if any plain_english has Flesch-Kincaid grade > 9 or any sentence > 20 words.
Only plain_english is reading-level-limited. FLAG-FOR-REVIEW terms skipped.
Usage: fk_gate.py [gNN|all]
"""
import json, os, sys, glob, re
import textstat

MAX_FK = 9.0
MAX_WORDS = 20

def sentences(text):
    return [p for p in re.split(r'(?<=[.!?])\s+', text.strip()) if p.strip()]

def main():
    arg = sys.argv[1] if len(sys.argv) > 1 else "all"
    names = (sorted(os.path.basename(p)[:-5] for p in glob.glob("authored_OUTPUT/*.json"))
             if arg == "all" else [arg])
    fails = []
    max_fk = 0.0; worst = None; n_terms = 0
    for n in names:
        ap = f"authored_OUTPUT/{n}.json"
        if not os.path.exists(ap):
            fails.append(f"{n}: missing file"); continue
        data = json.load(open(ap, encoding='utf-8'))
        terms = data.get("terms", data if isinstance(data, list) else [])
        for t in terms:
            if t.get("confidence") == "FLAG-FOR-REVIEW":
                continue
            pe = (t.get("plain_english") or "").strip()
            if not pe:
                fails.append(f"{n}/{t.get('term')}: empty plain_english"); continue
            n_terms += 1
            fk = textstat.flesch_kincaid_grade(pe)
            if fk > max_fk:
                max_fk = fk; worst = f"{n}/{t.get('term')}"
            if fk > MAX_FK:
                fails.append(f"{n}/{t.get('term')}: FK {fk:.1f} > {MAX_FK}")
            for s in sentences(pe):
                wc = len(s.split())
                if wc > MAX_WORDS:
                    fails.append(f"{n}/{t.get('term')}: sentence {wc}w > {MAX_WORDS}: {s[:55]}...")
    if fails:
        print(f"FK GATE FAIL — {len(fails)} issue(s); max FK {max_fk:.1f} ({worst}):")
        for f in fails[:200]:
            print("  -", f)
        if len(fails) > 200:
            print(f"  ... +{len(fails)-200} more")
        sys.exit(1)
    print(f"FK GATE OK — {n_terms} terms, max FK {max_fk:.1f} ({worst}), all sentences <= {MAX_WORDS}w.")

if __name__ == "__main__":
    main()
