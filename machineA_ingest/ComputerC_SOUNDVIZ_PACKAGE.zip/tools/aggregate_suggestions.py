#!/usr/bin/env python3
"""Aggregate all four experts' reviews. Print OK-rate + severity spread. Split into:
  corrections_todo.json   - editor fixes (technical/clarity/pedagogy/legal-copyright)
  report_difficulty.json  - difficulty retag recs (structural; report only)
  report_termflags.json   - term-rename / duplicate-entry flags (report only)
  report_legal_citations.json - Job 2 mark/citation list (post-review symbol pass)
"""
import json, os, glob
from collections import defaultdict

def main():
    groups = sorted(int(os.path.basename(p)[6:8]) for p in glob.glob("review_packets/group_*.json"))
    term_meta = {}
    for g in groups:
        gd = json.load(open(f"review_packets/group_{g:02d}.json", encoding='utf-8'))
        for t in gd["terms"]:
            term_meta[t["id"]] = {"term": t["term"], "difficulty": t.get("difficulty", ""),
                                  "category": t.get("category", "")}
    total = 0; ok = 0
    verdicts = defaultdict(int); sev = defaultdict(int)
    corrections = defaultdict(list)
    difficulty_recs = []; termflags = []; legal_citations = []
    for g in groups:
        for ex in ["audio", "cognition", "language", "legal"]:
            fp = f"committee_OUTPUT/{ex}_{g:02d}.json"
            if not os.path.exists(fp):
                continue
            d = json.load(open(fp, encoding='utf-8'))
            for r in d.get("reviews", []):
                total += 1
                v = r.get("verdict", "OK")
                verdicts[v] += 1
                if v == "OK":
                    ok += 1
                for s in (r.get("suggestions", []) or []):
                    sev[s.get("severity", "?")] += 1
                    field = (s.get("field", "") or "").lower()
                    issue = (s.get("issue", "") or "")
                    entry = {"id": r.get("id"), "term": r.get("term"), "expert": ex,
                             "field": s.get("field", ""), "severity": s.get("severity", ""),
                             "issue": issue, "suggestion": s.get("suggestion", "")}
                    if field == "difficulty" or issue.lower().startswith("difficulty"):
                        difficulty_recs.append(entry)
                    elif field in ("term", "duplicate", "rename") or "duplicate entry" in issue.lower():
                        termflags.append(entry)
                    else:
                        corrections[r.get("id")].append(entry)
            if ex == "legal":
                legal_citations += (d.get("legal_citations", []) or [])
    json.dump(difficulty_recs, open("report_difficulty.json", "w"), indent=2)
    json.dump(termflags, open("report_termflags.json", "w"), indent=2)
    json.dump(legal_citations, open("report_legal_citations.json", "w"), indent=2)
    corr_out = [{"id": k, "term": term_meta.get(k, {}).get("term"),
                 "category": term_meta.get(k, {}).get("category"), "fixes": v}
                for k, v in corrections.items()]
    json.dump(corr_out, open("corrections_todo.json", "w"), indent=2)
    rate = 100.0 * ok / total if total else 0.0
    print(f"reviews: {total}   OK: {ok} ({rate:.1f}%)")
    print("verdicts:", dict(verdicts))
    print("severities:", dict(sev))
    print(f"corrections_todo terms: {len(corr_out)}   difficulty_recs: {len(difficulty_recs)}   "
          f"termflags: {len(termflags)}   legal_citations: {len(legal_citations)}")

if __name__ == "__main__":
    main()
