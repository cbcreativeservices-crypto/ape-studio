#!/usr/bin/env python3
"""Build topic-coherent packets for a Computer C wave.

Handles BOTH of C's job types automatically, per input CSV columns:

  * UPDATE jobs (fill-empty / definition-only): the CSV already carries an `id`
    column (the real glossary UUID from Machine A's export). That id is CARRIED
    THROUGH unchanged — packets/authored rows/delivery all key on it. Any
    `existing_definition` / `empty_fields` / `authored_fields` columns are passed
    into each packet term so the author knows exactly what to write vs. keep.

  * INSERT jobs (new terms): the CSV has NO `id` column. A stable id is generated
    id = uuid5(NS, "term||landing_topic") with NS = uuid5(NAMESPACE_DNS,
    "apne.computerC.glossary.2026").  ***Computer C uses its OWN namespace*** so
    its generated ids never collide with Computer B's.

Concept pointer: carried from `concept_hint` (or `working_note`) — a
disambiguation hint only; authors must NOT paraphrase it into field text.

Usage: build_packets.py <terms.csv> [PACKET_SIZE]
Reads column `landing_topic` (falls back to `primary_topic`) for topic grouping.
"""
import csv, json, os, sys, uuid
from collections import OrderedDict

NS = uuid.uuid5(uuid.NAMESPACE_DNS, "apne.computerC.glossary.2026")

EMPTY = {
    "difficulty": "", "definition": "", "plain_english": "", "purpose_function": "",
    "practical_application": "", "related_terms": [], "common_mistakes": [],
    "scenario_contexts": [], "formula_symbolic": "", "formula_words": "",
    "confidence": "", "flags": "",
}

def make_id(term, topic):
    return str(uuid.uuid5(NS, f"{term}||{topic}"))

def topic_of(r):
    return (r.get("landing_topic") or r.get("primary_topic") or "").strip()

def main():
    if len(sys.argv) < 2:
        sys.exit("usage: build_packets.py <terms.csv> [PACKET_SIZE]")
    path = sys.argv[1]
    PACKET_SIZE = int(sys.argv[2]) if len(sys.argv) > 2 else 13
    rows = list(csv.DictReader(open(path, newline='', encoding='utf-8')))
    has_id = rows and ("id" in rows[0] and any((r.get("id") or "").strip() for r in rows))
    mode = "UPDATE (id carried from CSV)" if has_id else "INSERT (id generated, C namespace)"
    topics = OrderedDict()
    for r in rows:
        topics.setdefault(topic_of(r), []).append(r)
    os.makedirs("packets", exist_ok=True)
    for f in os.listdir("packets"):
        if f.endswith(".json"):
            os.remove(os.path.join("packets", f))
    pkt_idx = 0; manifest = []; seen = {}
    for topic, trows in topics.items():
        for i in range(0, len(trows), PACKET_SIZE):
            pkt_idx += 1
            chunk = trows[i:i + PACKET_SIZE]
            name = f"g{pkt_idx:02d}"
            terms = []
            for r in chunk:
                term = r["term"].strip()
                tid = (r.get("id") or "").strip() if has_id else make_id(term, topic)
                if tid in seen:
                    print(f"  !! DUP id: {term!r} vs {seen[tid]!r}")
                seen[tid] = term
                obj = {
                    "id": tid, "term": term,
                    "subject": (r.get("subject") or "").strip(),
                    "category": topic,
                    "status": (r.get("status") or "").strip(),
                    "source_batch": (r.get("source_batch") or "").strip(),
                    "concept_hint": (r.get("concept_hint") or r.get("working_note") or "").strip(),
                }
                # pass-through helpers for UPDATE/fill jobs (author reads, delivery may use)
                for extra in ("existing_definition", "empty_fields", "authored_fields", "primary_topic"):
                    if extra in r and (r.get(extra) or "").strip():
                        obj[extra] = r[extra].strip()
                obj.update(json.loads(json.dumps(EMPTY)))
                terms.append(obj)
            pkt = {"packet": name, "landing_topic": topic,
                   "subject": (chunk[0].get("subject") or "").strip(),
                   "source_batch": (chunk[0].get("source_batch") or "").strip(),
                   "count": len(terms), "terms": terms}
            json.dump(pkt, open(f"packets/{name}.json", "w", encoding='utf-8'),
                      ensure_ascii=False, indent=2)
            manifest.append((name, topic, len(terms)))
    total = sum(m[2] for m in manifest)
    print(f"mode: {mode}")
    print(f"CSV rows: {len(rows)}   unique ids: {len(seen)}   packets: {len(manifest)}   total: {total}")
    cur = None
    for name, topic, n in manifest:
        if topic != cur:
            print(f"\n== {topic} =="); cur = topic
        print(f"  {name}: {n}")
    assert total == len(rows) and len(seen) == len(rows), "count/id mismatch"
    print("\nOK: packet build complete.")

if __name__ == "__main__":
    main()
