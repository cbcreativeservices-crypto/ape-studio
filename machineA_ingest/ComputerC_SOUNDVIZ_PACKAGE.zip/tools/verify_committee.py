#!/usr/bin/env python3
"""Verify committee output: for each group, all four expert files exist, parse,
have exactly one review per term in packet order, valid verdicts; legal file has a
legal_citations array. Usage: verify_committee.py [group_NN|all]
"""
import json, os, sys, glob

EXPERTS = ["audio", "cognition", "language", "legal"]
VERDICTS = {"OK", "MINOR", "NEEDS_REVISION"}

def check_group(gnum, errors):
    gp = f"review_packets/group_{gnum:02d}.json"
    if not os.path.exists(gp):
        errors.append(f"group_{gnum:02d}: missing review packet"); return
    g = json.load(open(gp, encoding='utf-8'))
    ids = [t["id"] for t in g["terms"]]
    for ex in EXPERTS:
        fp = f"committee_OUTPUT/{ex}_{gnum:02d}.json"
        if not os.path.exists(fp):
            errors.append(f"{ex}_{gnum:02d}: MISSING"); continue
        try:
            d = json.load(open(fp, encoding='utf-8'))
        except Exception as e:
            errors.append(f"{ex}_{gnum:02d}: parse error {e}"); continue
        revs = d.get("reviews", [])
        if len(revs) != len(ids):
            errors.append(f"{ex}_{gnum:02d}: {len(revs)} reviews != {len(ids)} terms")
        for j, (r, tid) in enumerate(zip(revs, ids)):
            if r.get("id") != tid:
                errors.append(f"{ex}_{gnum:02d}: review[{j}] id mismatch (order)")
            if r.get("verdict") not in VERDICTS:
                errors.append(f"{ex}_{gnum:02d}: review[{j}] bad verdict {r.get('verdict')!r}")
        if ex == "legal" and "legal_citations" not in d:
            errors.append(f"legal_{gnum:02d}: missing legal_citations array (use [] if none)")

def main():
    arg = sys.argv[1] if len(sys.argv) > 1 else "all"
    groups = sorted(int(os.path.basename(p)[6:8]) for p in glob.glob("review_packets/group_*.json"))
    if arg != "all":
        groups = [int(arg.replace("group_", ""))]
    errors = []
    for g in groups:
        check_group(g, errors)
    if errors:
        print(f"COMMITTEE VERIFY FAIL — {len(errors)} error(s):")
        for e in errors[:200]:
            print("  -", e)
        sys.exit(1)
    print(f"COMMITTEE VERIFY OK — {len(groups)} group(s) x4 experts, counts + order match.")

if __name__ == "__main__":
    main()
