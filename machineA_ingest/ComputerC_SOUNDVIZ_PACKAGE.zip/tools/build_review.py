#!/usr/bin/env python3
"""Assemble committee review packets (~35 terms/group) with full authored fields,
preserving packet order. Writes review_packets/group_NN.json.
"""
import json, os, glob

GROUP_SIZE = 35

def main():
    names = sorted(os.path.basename(p)[:-5] for p in glob.glob("authored_OUTPUT/*.json"))
    allterms = []
    for n in names:
        data = json.load(open(f"authored_OUTPUT/{n}.json", encoding='utf-8'))
        allterms += data.get("terms", data if isinstance(data, list) else [])
    os.makedirs("review_packets", exist_ok=True)
    for f in glob.glob("review_packets/*.json"):
        os.remove(f)
    ngroups = 0
    for i in range(0, len(allterms), GROUP_SIZE):
        ngroups += 1
        chunk = allterms[i:i + GROUP_SIZE]
        g = {"group": ngroups, "count": len(chunk), "terms": chunk}
        json.dump(g, open(f"review_packets/group_{ngroups:02d}.json", "w", encoding='utf-8'),
                  ensure_ascii=False, indent=2)
    print(f"built {ngroups} review groups from {len(allterms)} terms (~{GROUP_SIZE}/group)")

if __name__ == "__main__":
    main()
