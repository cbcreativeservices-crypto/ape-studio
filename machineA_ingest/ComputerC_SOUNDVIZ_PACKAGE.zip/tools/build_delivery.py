#!/usr/bin/env python3
"""Validate the corrected authored corpus and build the Machine A return bundle.
Validation (hard fail): 0 empty required fields, 0 empty list fields, unique ids,
0 stray (c)/(tm)/(r) marks in any field text, plain_english FK<=9. Writes:
  ComputerC_committee_reviewed.csv (INSERT-ready; list fields as JSON strings)
  merge_payload.json / merge_payload.ndjson
  BOOTH_difficulty_recs.json, LEGAL_citations.json, term_duplicate_flags.json,
  flagged_contested_for_booth.json, CHECKSUMS.txt
"""
import json, os, sys, glob, csv, hashlib
import textstat

import os
WAVE = (sys.argv[1] if len(sys.argv) > 1 else os.environ.get("WAVE", "WAVE_UNSET"))
OUTDIR = f"deliverable/DELIVERY_MachineA_{WAVE}"
LIST_FIELDS = ["related_terms", "common_mistakes", "scenario_contexts"]
TEXT_FIELDS = ["definition", "plain_english", "purpose_function", "practical_application",
               "formula_symbolic", "formula_words"]
MARKS = ["©", "™", "®"]  # © ™ ®

def all_terms():
    out = []
    for n in sorted(os.path.basename(p)[:-5] for p in glob.glob("authored_OUTPUT/*.json")):
        d = json.load(open(f"authored_OUTPUT/{n}.json", encoding='utf-8'))
        out += d.get("terms", d if isinstance(d, list) else [])
    return out

def main():
    terms = all_terms()
    errors = []; ids = set()
    for t in terms:
        if t.get("confidence") == "FLAG-FOR-REVIEW":
            continue
        tid = t.get("id")
        if tid in ids:
            errors.append(f"dup id {tid} ({t.get('term')})")
        ids.add(tid)
        for f in ["definition", "plain_english", "purpose_function", "practical_application",
                  "category", "difficulty"]:
            if not str(t.get(f, "")).strip():
                errors.append(f"{t.get('term')}: empty {f}")
        for f in LIST_FIELDS:
            if not isinstance(t.get(f), list) or not t.get(f):
                errors.append(f"{t.get('term')}: empty list {f}")
        for f in TEXT_FIELDS + LIST_FIELDS:
            v = t.get(f); blob = " ".join(v) if isinstance(v, list) else str(v)
            for m in MARKS:
                if m in blob:
                    errors.append(f"{t.get('term')}: stray mark in {f}")
        pe = (t.get("plain_english") or "").strip()
        if pe and textstat.flesch_kincaid_grade(pe) > 9.0:
            errors.append(f"{t.get('term')}: FK>9")
    flagged = [t for t in terms if t.get("confidence") == "FLAG-FOR-REVIEW"]
    if errors:
        print(f"DELIVERY VALIDATION FAIL — {len(errors)}:")
        for e in errors[:120]:
            print("  -", e)
        sys.exit(1)
    os.makedirs(OUTDIR, exist_ok=True)
    deliver = [t for t in terms if t.get("confidence") != "FLAG-FOR-REVIEW"]
    cols = ["id", "term", "subject", "category", "difficulty", "definition", "plain_english",
            "purpose_function", "practical_application", "related_terms", "common_mistakes",
            "scenario_contexts", "formula_symbolic", "formula_words", "confidence", "status",
            "source_batch"]
    with open(f"{OUTDIR}/ComputerC_committee_reviewed.csv", "w", newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=cols); w.writeheader()
        for t in deliver:
            row = {c: t.get(c, "") for c in cols}
            for lf in LIST_FIELDS:
                row[lf] = json.dumps(t.get(lf, []), ensure_ascii=False)
            w.writerow(row)
    json.dump(deliver, open(f"{OUTDIR}/merge_payload.json", "w", encoding='utf-8'),
              ensure_ascii=False, indent=2)
    with open(f"{OUTDIR}/merge_payload.ndjson", "w", encoding='utf-8') as fh:
        for t in deliver:
            fh.write(json.dumps(t, ensure_ascii=False) + "\n")
    for src, dst in [("report_difficulty.json", "BOOTH_difficulty_recs.json"),
                     ("report_legal_citations.json", "LEGAL_citations.json"),
                     ("report_termflags.json", "term_duplicate_flags.json")]:
        data = json.load(open(src)) if os.path.exists(src) else []
        json.dump(data, open(f"{OUTDIR}/{dst}", "w"), indent=2)
    json.dump(flagged, open(f"{OUTDIR}/flagged_contested_for_booth.json", "w", encoding='utf-8'),
              ensure_ascii=False, indent=2)
    with open(f"{OUTDIR}/CHECKSUMS.txt", "w") as fh:
        for f in sorted(os.listdir(OUTDIR)):
            if f == "CHECKSUMS.txt":
                continue
            h = hashlib.sha256(open(f"{OUTDIR}/{f}", "rb").read()).hexdigest()
            fh.write(f"{h}  {f}\n")
    print(f"DELIVERY OK — {len(deliver)} terms delivered, {len(flagged)} flagged. -> {OUTDIR}")

if __name__ == "__main__":
    main()
