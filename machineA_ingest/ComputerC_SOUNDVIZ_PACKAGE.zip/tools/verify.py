#!/usr/bin/env python3
"""Structural verifier for authored_OUTPUT/gNN.json.
Checks: all required fields present/non-empty, list fields non-empty arrays of
non-empty strings, difficulty/confidence valid, category==packet topic verbatim,
id/term/category never altered from packet, no placeholders, no URLs/citations in
field text, formula fields consistent. FLAG-FOR-REVIEW terms may be blank but need
a flags reason. Usage: verify.py [gNN|all]
"""
import json, os, sys, glob

REQ_STR = ["definition", "plain_english", "purpose_function", "practical_application",
           "category", "difficulty", "confidence"]
REQ_LIST = ["related_terms", "common_mistakes", "scenario_contexts"]
DIFFS = {"beginner", "intermediate", "advanced"}
CONF = {"High", "Medium", "FLAG-FOR-REVIEW"}
PLACEHOLDERS = ["tbd", "to be determined", "todo", "placeholder", "lorem ipsum",
                "xxxx", "fixme", "[insert", "[add"]

def load_packet(name):
    p = f"packets/{name}.json"
    return json.load(open(p, encoding='utf-8')) if os.path.exists(p) else None

def check_file(name, errors):
    ap = f"authored_OUTPUT/{name}.json"
    if not os.path.exists(ap):
        errors.append(f"{name}: MISSING authored_OUTPUT/{name}.json"); return
    try:
        data = json.load(open(ap, encoding='utf-8'))
    except Exception as e:
        errors.append(f"{name}: JSON parse error: {e}"); return
    pkt = load_packet(name)
    pkt_terms = {t["id"]: t for t in pkt["terms"]} if pkt else {}
    terms = data.get("terms", data if isinstance(data, list) else [])
    if pkt and len(terms) != pkt["count"]:
        errors.append(f"{name}: term count {len(terms)} != packet {pkt['count']}")
    for t in terms:
        tid = t.get("id", "?"); term = t.get("term", "?")
        tag = f"{name}/{term}"
        if pkt:
            if tid in pkt_terms:
                for k in ("term", "category", "id"):
                    if t.get(k) != pkt_terms[tid].get(k):
                        errors.append(f"{tag}: {k} altered ({t.get(k)!r} != {pkt_terms[tid].get(k)!r})")
            else:
                errors.append(f"{tag}: id {tid} not in packet")
        conf = t.get("confidence", "")
        if conf not in CONF:
            errors.append(f"{tag}: bad confidence {conf!r}")
        if conf == "FLAG-FOR-REVIEW":
            if not str(t.get("flags", "")).strip():
                errors.append(f"{tag}: FLAG-FOR-REVIEW but no flags reason")
            continue
        for f in REQ_STR:
            v = t.get(f, "")
            if not isinstance(v, str) or not v.strip():
                errors.append(f"{tag}: empty/invalid field {f}")
            elif any(ph in v.lower() for ph in PLACEHOLDERS):
                errors.append(f"{tag}: placeholder-like text in {f}")
        if t.get("difficulty") not in DIFFS:
            errors.append(f"{tag}: bad difficulty {t.get('difficulty')!r}")
        for f in REQ_LIST:
            v = t.get(f)
            if not isinstance(v, list) or len(v) == 0:
                errors.append(f"{tag}: list field {f} empty/invalid"); continue
            for item in v:
                if not isinstance(item, str) or not item.strip():
                    errors.append(f"{tag}: empty item in {f}")
                elif any(ph in item.lower() for ph in PLACEHOLDERS):
                    errors.append(f"{tag}: placeholder-like item in {f}")
        for f in REQ_STR + REQ_LIST:
            v = t.get(f)
            blob = " ".join(v) if isinstance(v, list) else str(v)
            for bad in ["http://", "https://", "www."]:
                if bad in blob.lower():
                    errors.append(f"{tag}: URL/citation in field {f}")
        fs = str(t.get("formula_symbolic", "")).strip()
        fw = str(t.get("formula_words", "")).strip()
        if bool(fs) != bool(fw):
            errors.append(f"{tag}: formula_symbolic/formula_words must both be set or both empty")

def main():
    arg = sys.argv[1] if len(sys.argv) > 1 else "all"
    names = sorted(os.path.basename(p)[:-5] for p in glob.glob("packets/*.json")) if arg == "all" else [arg]
    errors = []
    for n in names:
        check_file(n, errors)
    if errors:
        print(f"VERIFY FAIL — {len(errors)} error(s):")
        for e in errors[:200]:
            print("  -", e)
        if len(errors) > 200:
            print(f"  ... +{len(errors)-200} more")
        sys.exit(1)
    print(f"VERIFY OK — {len(names)} packet(s), 0 errors.")

if __name__ == "__main__":
    main()
