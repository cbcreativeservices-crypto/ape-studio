# START HERE — Computer C · SOUND VISUALIZATION & SCIENTIFIC ACOUSTICS package

Self-contained. Nothing to fetch elsewhere.

```
ComputerC_SOUNDVIZ_terms.csv     <- the 1,664 terms to author (deduped vs live glossary)
HANDOFF_ComputerC_SOUNDVIZ.md    <- read this: scope, branches, tiers, deliverable
tools/                           <- the pipeline (build_packets → ... → build_delivery)
briefs/
  AUTHORING_GUIDE_shared.md      <- canonical spec (read first)
  AUTHORING_BRIEF_c.md           <- graduate-student authoring rules
  COMMITTEE_BRIEF_c.md           <- 4-expert committee review rules
```

## Quickstart
```
pip install textstat --break-system-packages
python tools/build_packets.py ComputerC_SOUNDVIZ_terms.csv
#   -> packets/gNN.json  (INSERT mode: ids minted in Computer C namespace)
# author each packet -> authored_OUTPUT/gNN.json  (per briefs/AUTHORING_BRIEF_c.md)
python tools/verify.py all
python tools/fk_gate.py all
python tools/build_review.py
# committee -> committee_OUTPUT/{audio,cognition,language,legal}_NN.json
python tools/verify_committee.py
python tools/aggregate_suggestions.py     # apply editor corrections; re-run verify + fk_gate
python tools/build_delivery.py SOUNDVIZ_2026_08_02
#   -> deliverable/DELIVERY_MachineA_SOUNDVIZ_2026_08_02/  (zip + send to Machine A)
```

## Job facts
- **INSERT** (new terms). No `id` column → build_packets mints stable ids
  (`uuid5(NAMESPACE_DNS,"apne.computerC.glossary.2026")`, then `uuid5(NS,"term||landing_topic")`).
- Author **all 8 fields + difficulty**; formulas only for equation/quantity terms.
- **1,384 Tier-1** (build) · **280 Tier-2** (interpretive — flag-don't-guess hard).
- `concept_hint` = a disambiguation pointer, present on ~1,000 terms. Never paraphrase it into text.
- `source_batch = SOUNDVIZ_2026_08_02`. Return corrected merge payload to Machine A only.
```
```
