# Computer C — Pipeline Toolkit

The author → 4-member committee → corrections → readability-gate → Machine-A delivery pipeline,
Computer-C flavored. Same discipline as every prior C wave. **You never write to the database —
you return a corrected payload to Machine A (sole DB writer).**

Python 3 + `textstat` (`pip install textstat --break-system-packages`). Run scripts from the wave's
working folder (the one holding your input CSV from Machine A).

## Files
- `briefs/AUTHORING_GUIDE_shared.md` — canonical spec (applies to B and C). Read first.
- `briefs/AUTHORING_BRIEF_c.md` — the graduate-student authoring rules (sourcing, copyright,
  plain_english ≤ grade 9, UNSAFE:, flag-don't-guess).
- `briefs/COMMITTEE_BRIEF_c.md` — the 4 experts (audio / cognition / language / **legal**), severity
  ladder, bias-to-OK.
- `build_packets.py` · `build_review.py` · `verify.py` · `fk_gate.py` · `aggregate_suggestions.py`
  · `verify_committee.py` · `build_delivery.py`.

## Run order
1. **`build_packets.py <terms.csv> [PACKET_SIZE]`** → `packets/gNN.json` (topic-coherent, ~13/pkt).
2. **Author** each packet → `authored_OUTPUT/gNN.json` (per `briefs/AUTHORING_BRIEF_c.md`).
3. **`verify.py all`** — structural gate (fields present, category==topic, no placeholders/citations,
   formula pairs consistent). Must be 0 errors.
4. **`fk_gate.py all`** — `plain_english` Flesch-Kincaid ≤ grade 9, sentences ≤ 20 words. 0 fails.
5. **`build_review.py`** → `review_packets/group_NN.json` (~35 terms/group).
6. **Committee:** each group reviewed by all 4 experts → `committee_OUTPUT/{audio,cognition,language,legal}_NN.json`
   (one review per term, packet order). **`verify_committee.py`** must be 0 errors.
7. **`aggregate_suggestions.py`** → apply editor corrections to `authored_OUTPUT/` (changed fields
   only; web-verify technical; keep a pre-correction snapshot; never change `id`/`term`/`difficulty`).
   Re-run `verify.py all` + `fk_gate.py all`.
8. **`build_delivery.py <WAVE>`** (or `WAVE=... build_delivery.py`) → `deliverable/DELIVERY_MachineA_<WAVE>/`
   with `ComputerC_committee_reviewed.csv`, `merge_payload.json/.ndjson`, `BOOTH_difficulty_recs.json`,
   `LEGAL_citations.json`, `term_duplicate_flags.json`, `flagged_contested_for_booth.json`, `CHECKSUMS.txt`.
   Zip that folder and send it to Machine A.

## Computer-C specifics (what differs from B)
- **ID namespace is Computer C's own:** `uuid5(NAMESPACE_DNS,"apne.computerC.glossary.2026")`. Used
  only for **new-term (INSERT) jobs** so C-generated ids never collide with B's.
- **UPDATE vs INSERT is auto-detected by `build_packets.py`:**
  - If your input CSV has an **`id` column** (fill-empty / definition-only jobs — the id is the real
    glossary UUID from Machine A's export), the id is **carried through unchanged**; delivery keys on
    it and Machine A applies as `UPDATE glossary SET <authored fields> WHERE id=…`. Author ONLY the
    fields you were asked for; leave everything else frozen.
  - If there is **no `id` column** (new-term jobs), an id is generated; Machine A applies as INSERT.
- **`(pending)` is empty.** If an input row's `existing_definition` is the literal `(pending)`, treat
  the definition as MISSING and author a real one (that placeholder is not a real definition).
- **`concept_hint` is a pointer, not text** — disambiguates the headword; never paraphrase it into a
  field.
- **`difficulty` is DB-owned:** author it for genuinely new rows; for fill/UPDATE jobs do NOT set it
  (report difficulty suggestions only).
- **Legal lens is central on standards/law-heavy waves.** No verbatim standard/legal text; attribute
  any numeric limit to its instrument/jurisdiction; UNSAFE: on hazards.

## Input CSV columns understood
`term` (required) · `landing_topic` or `primary_topic` (topic grouping) · optional: `id`,
`subject`, `status`, `source_batch`, `concept_hint`/`working_note`, `existing_definition`,
`empty_fields`, `authored_fields`.

_Provenance: assembled from the shared AP&E authoring/committee pipeline (2026-07-29 spec). Scripts
are the shared pipeline; `build_packets.py` and `build_delivery.py` are the Computer-C-adapted
versions. If a canonical `APNE_ComputerC_TOOLKIT` exists elsewhere, prefer it and confirm the id
scheme matches._
